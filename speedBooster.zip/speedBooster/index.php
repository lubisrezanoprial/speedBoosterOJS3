<?php
/**
 * @file plugins/generic/speedBooster/index.php
 *
 * Speed & Performance Booster Plugin Entry Point
 */

require_once('SpeedBoosterPlugin.inc.php');

return new SpeedBoosterPlugin();